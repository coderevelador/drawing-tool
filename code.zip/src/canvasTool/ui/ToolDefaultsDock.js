import { useCanvasStore } from "../state/canvasStore";

export function ensureToolDefaultsDock(engine) {
  const store = engine.store;
  const host = engine.canvas.parentElement || document.body;

  // If already present, return it
  const existing = host.querySelector('[data-role="tool-defaults-dock"]');
  if (existing)
    return {
      destroy() {
        existing.remove();
      },
    };

  const el = document.createElement("div");
  el.dataset.role = "tool-defaults-dock";
  Object.assign(el.style, {
    position: "absolute",
    top: "16px",
    right: "16px",
    zIndex: 1002,
    background: "#0b1020",
    color: "#eee",
    padding: "10px 12px",
    borderRadius: "12px",
    boxShadow: "0 6px 24px rgba(0,0,0,.35)",
    fontFamily: "ui-sans-serif, system-ui, -apple-system, Segoe UI, Roboto",
    fontSize: "12px",
    minWidth: "240px",
    pointerEvents: "auto",
    border: "1px solid rgba(255,255,255,.08)",
  });

  const title = document.createElement("div");
  title.textContent = "Tool Defaults";
  Object.assign(title.style, {
    fontWeight: 700,
    marginBottom: "8px",
    fontSize: "12px",
    opacity: 0.9,
  });
  el.appendChild(title);

  const row = (label, input) => {
    const wrap = document.createElement("label");
    Object.assign(wrap.style, {
      display: "grid",
      gridTemplateColumns: "1fr 1fr",
      alignItems: "center",
      gap: "8px",
      margin: "6px 0",
    });
    const lab = document.createElement("div");
    lab.textContent = label;
    lab.style.opacity = 0.9;
    wrap.appendChild(lab);
    wrap.appendChild(input);
    return wrap;
  };

  const mkColor = () => {
    const i = document.createElement("input");
    i.type = "color";
    Object.assign(i.style, {
      width: "100%",
      height: "28px",
      background: "transparent",
      border: "1px solid rgba(255,255,255,.12)",
      borderRadius: "6px",
    });
    return i;
  };
}
