// InspectorDock.js
// Always-on, movable side panel that lists objects and renders editor from tool schemas.
// Hand-cursor move for selected item (no square selection; soft glow instead).
// Includes fallback schema so common properties are always visible.

import { useCanvasStore } from "../state/canvasStore";
import { SchemaRegistry, dget, dset } from "../utils/schemaRegistry";

export function mountInspectorDock(engine, opts = {}) {
  const startPinnedRight = opts.startPinnedRight ?? true;

  // -------- store helpers ----------
  const getObjects = () => (useCanvasStore.getState().objects || []);
  const setObjects = (next) => {
    const s = useCanvasStore.getState();
    if (typeof s.setState === "function") s.setState({ objects: next });
    else if (typeof useCanvasStore.setState === "function") useCanvasStore.setState({ objects: next });
  };

  // ---------- selection state ----------
  let selectedIdx = -1;

  // ---------- draw selection glow (no dashed box) ----------
  function drawSelectionGlow(ctx, obj) {
    if (!obj) return;
    const d = obj.data || {};
    const s = obj.style || {};
    const lw = Number(s.lineWidth || 2);

    const glow = (pathFn, w = lw) => {
      ctx.save();
      ctx.lineJoin = "round";
      ctx.lineCap = "round";
      ctx.strokeStyle = "rgba(37,99,235,.9)"; // blue-600
      ctx.lineWidth = w + 2;
      ctx.shadowColor = "rgba(59,130,246,.35)";
      ctx.shadowBlur = 6;
      pathFn();
      ctx.stroke();
      ctx.restore();
    };

    const pathRect = () => {
      ctx.beginPath();
      ctx.rect(+d.x || 0, +d.y || 0, +d.width || 0, +d.height || 0);
    };
    const pathCircle = () => {
      const x = +d.x || 0, y = +d.y || 0, w = +d.width || 0, h = +d.height || 0;
      ctx.beginPath();
      ctx.ellipse(x + w / 2, y + h / 2, Math.abs(w / 2), Math.abs(h / 2), 0, 0, Math.PI * 2);
    };
    const pathLine = () => {
      const x1 = d.x1 ?? d.x ?? 0, y1 = d.y1 ?? d.y ?? 0;
      const x2 = d.x2 ?? ((d.x ?? 0) + (d.width ?? 0));
      const y2 = d.y2 ?? ((d.y ?? 0) + (d.height ?? 0));
      ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2, y2);
    };
    const pathPolyline = () => {
      const pts = d.points || [];
      if (pts.length < 2) return;
      ctx.beginPath(); ctx.moveTo(pts[0].x, pts[0].y);
      for (let i = 1; i < pts.length; i++) ctx.lineTo(pts[i].x, pts[i].y);
      if (d.closed) ctx.closePath();
    };

    switch (obj.type) {
      case "rect": glow(pathRect); break;
      case "circle": glow(pathCircle); break;
      case "line":
      case "arrow": glow(pathLine); break;
      case "polyline":
      case "highlighter": glow(pathPolyline); break;
      case "text":
      case "sticky":
      case "watermark": glow(pathRect, 1); break; // bbox-ish glow for text-like
      default: break;
    }
  }

  const repaintWithSelection = () => {
    engine.renderAllObjects();
    if (selectedIdx >= 0) {
      const obj = getObjects()[selectedIdx];
      if (obj) drawSelectionGlow(engine.ctx, obj);
    }
  };

  const iconFor = (type) => {
    switch (type) {
      case "rect": return "▭";
      case "circle": return "◯";
      case "line": return "／";
      case "polyline": return "〰";
      case "arrow": return "➤";
      case "highlighter": return "🖍️";
      case "censor": return "🧊";
      case "text": return "🅣";
      case "sticky": return "🗒️";
      case "snapshot": return "📸";
      case "watermark": return "🏷️";
      default: return "⬚";
    }
  };

  // -------- geometry / hits ----------
  const getBounds = (obj) => {
    const d = obj?.data || {};
    if (!obj) return { x: 0, y: 0, w: 0, h: 0 };
    switch (obj.type) {
      case "polyline":
      case "highlighter": {
        const pts = d.points || [];
        if (!pts.length) return { x: 0, y: 0, w: 0, h: 0 };
        let minX = pts[0].x, minY = pts[0].y, maxX = pts[0].x, maxY = pts[0].y;
        for (const p of pts) { if (p.x < minX) minX = p.x; if (p.y < minY) minY = p.y; if (p.x > maxX) maxX = p.x; if (p.y > maxY) maxY = p.y; }
        return { x: minX, y: minY, w: maxX - minX, h: maxY - minY };
      }
      default: {
        const x = Number(d.x || 0), y = Number(d.y || 0);
        const w = Number(d.width || d.w || 0) || 200;
        const h = Number(d.height || d.h || 0) || 60;
        return { x, y, w, h };
      }
    }
  };

  const distToSeg = (p, a, b) => {
    const vx = b.x - a.x, vy = b.y - a.y;
    const wx = p.x - a.x, wy = p.y - a.y;
    const c1 = vx * wx + vy * wy;
    if (c1 <= 0) return Math.hypot(p.x - a.x, p.y - a.y);
    const c2 = vx * vx + vy * vy;
    if (c2 <= c1) return Math.hypot(p.x - b.x, p.y - b.y);
    const t = c1 / c2;
    const proj = { x: a.x + t * vx, y: a.y + t * vy };
    return Math.hypot(p.x - proj.x, p.y - proj.y);
  };

  const isHit = (obj, pos) => {
    const d = obj?.data || {};
    if (!obj) return false;

    const box = getBounds(obj);
    const inBox = pos.x >= box.x && pos.x <= box.x + box.w && pos.y >= box.y && pos.y <= box.y + box.h;

    switch (obj.type) {
      case "line":
      case "arrow": {
        const a = { x: d.x1 ?? d.x ?? box.x, y: d.y1 ?? d.y ?? box.y };
        const b = { x: d.x2 ?? (d.x ?? 0) + (d.width ?? box.w), y: d.y2 ?? (d.y ?? 0) + (d.height ?? box.h) };
        const tol = Math.max(6, (obj.style?.lineWidth || 2) + 4);
        return distToSeg(pos, a, b) <= tol;
      }
      case "polyline":
      case "highlighter": {
        if (!inBox) return false;
        const pts = d.points || [];
        const tol = Math.max(6, (obj.style?.lineWidth || 8) * 0.75);
        for (let i = 0; i < pts.length - 1; i++) {
          if (distToSeg(pos, pts[i], pts[i + 1]) <= tol) return true;
        }
        return false;
      }
      default:
        return inBox;
    }
  };

  // -------- panel DOM ----------
  const panel = document.createElement("div");
  panel.className = "inspector-dark";
  Object.assign(panel.style, {
    position: "fixed",
    top: "80px",
    right: startPinnedRight ? "16px" : "auto",
    left: startPinnedRight ? "auto" : "16px",
    width: "320px",
    maxHeight: "80vh",
    display: "flex",
    flexDirection: "column",
    background: "#0f172a",
    color: "#e5e7eb",
    borderRadius: "12px",
    boxShadow: "0 12px 32px rgba(0,0,0,.35)",
    font: "12px system-ui, -apple-system, Segoe UI, Roboto, sans-serif",
    overflow: "hidden",
    zIndex: 3000,
    userSelect: "none"
  });

  const header = document.createElement("div");
  Object.assign(header.style, {
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    gap: "8px",
    padding: "10px",
    background: "#111827",
    cursor: "grab"
  });
  header.innerHTML = `
    <div style="display:flex;align-items:center;gap:8px">
      <span style="opacity:.7;letter-spacing:2px;">⋮⋮</span>
      <strong>Objects</strong>
    </div>
    <div style="display:flex;gap:6px;align-items:center">
      <label style="display:flex;gap:6px;align-items:center;cursor:pointer">
        <input type="checkbox" id="moveToggle" checked>
        <span>Drag to move</span>
      </label>
      <button id="expSel" style="background:#0ea5e9;color:#fff;border:0;border-radius:8px;padding:4px 8px;cursor:pointer">Save Selected</button>
      <button id="expAll" style="background:#22c55e;color:#0b1419;border:0;border-radius:8px;padding:4px 8px;cursor:pointer">Save All</button>
    </div>`;
  panel.appendChild(header);

  // dark input styles (scoped)
  const styleTag = document.createElement("style");
  styleTag.textContent = `
    .inspector-dark input, .inspector-dark select, .inspector-dark textarea {
      background:#0b1220; color:#e5e7eb; border:1px solid rgba(255,255,255,.15);
      border-radius:8px; padding:6px 8px; outline:none;
    }
    .inspector-dark input[type="color"] { padding:0; height:32px; }
    .inspector-dark button { font:inherit; }
    .inspector-dark label { color:#cbd5e1; }
  `;
  panel.appendChild(styleTag);

  // drag panel itself
  let draggingPanel = false, offX = 0, offY = 0;
  header.addEventListener("pointerdown", (e) => {
    draggingPanel = true;
    header.setPointerCapture(e.pointerId);
    header.style.cursor = "grabbing";
    const r = panel.getBoundingClientRect();
    offX = e.clientX - r.left;
    offY = e.clientY - r.top;
    panel.style.right = "auto";
  });
  const endPanelDrag = (e) => {
    if (!draggingPanel) return;
    draggingPanel = false;
    header.releasePointerCapture?.(e.pointerId);
    header.style.cursor = "grab";
  };
  header.addEventListener("pointermove", (e) => {
    if (!draggingPanel) return;
    panel.style.left = (e.clientX - offX) + "px";
    panel.style.top = (e.clientY - offY) + "px";
  });
  header.addEventListener("pointerup", endPanelDrag);
  header.addEventListener("pointercancel", endPanelDrag);

  const body = document.createElement("div");
  Object.assign(body.style, {
    display: "grid",
    gridTemplateRows: "minmax(140px, 1fr) auto",
    minHeight: "320px"
  });
  panel.appendChild(body);

  // list
  const listWrap = document.createElement("div");
  Object.assign(listWrap.style, {
    overflow: "auto",
    borderBottom: "1px solid rgba(255,255,255,0.08)"
  });
  const list = document.createElement("div");
  list.style.padding = "6px";
  listWrap.appendChild(list);
  body.appendChild(listWrap);

  // inspector
  const insp = document.createElement("div");
  Object.assign(insp.style, {
    padding: "10px",
    display: "grid",
    gap: "8px",
    overflow: "auto",
    maxHeight: "calc(100vh - 220px)"
  });
  body.appendChild(insp);

  document.body.appendChild(panel);

  // layer change
  const changeLayer = (idx, delta) => {
    const arr = getObjects().slice();
    if (!arr[idx]) return;
    arr[idx].layer = Math.max(0, (arr[idx].layer || 0) + delta);
    setObjects(arr);
    repaintWithSelection();
  };

  // render list
  const renderList = () => {
    const objs = getObjects();
    list.innerHTML = "";

    objs.forEach((o, idx) => {
      const row = document.createElement("button");
      Object.assign(row.style, {
        width: "100%",
        display: "grid",
        gridTemplateColumns: "20px 1fr 60px",
        gap: "8px",
        alignItems: "center",
        padding: "6px 8px",
        marginBottom: "4px",
        borderRadius: "8px",
        border: "0",
        cursor: "pointer",
        background: idx === selectedIdx ? "#1f2937" : "transparent",
        color: "inherit",
        textAlign: "left"
      });

      const swatch = document.createElement("div");
      Object.assign(swatch.style, {
        width: "14px", height: "14px", borderRadius: "50%",
        background: (o.style?.stroke || o.style?.fill || "#6b7280"),
        border: "1px solid rgba(255,255,255,.25)"
      });

      const label = document.createElement("div");
      const name = o.name || `${o.type}`;
      label.textContent = `${iconFor(o.type)}  ${name}`;
      label.style.overflow = "hidden";
      label.style.textOverflow = "ellipsis";
      label.style.whiteSpace = "nowrap";

      const layerCtl = document.createElement("div");
      layerCtl.style.display = "flex"; layerCtl.style.gap = "6px";
      const up = document.createElement("button");
      const down = document.createElement("button");
      up.textContent = "▲"; down.textContent = "▼";
      [up, down].forEach(b => Object.assign(b.style, {
        border: "0", borderRadius: "6px", padding: "2px 6px",
        background: "#111827", color: "#e5e7eb", cursor: "pointer"
      }));
      up.onclick = (e) => { e.stopPropagation(); changeLayer(idx, +1); };
      down.onclick = (e) => { e.stopPropagation(); changeLayer(idx, -1); };

      row.onclick = () => { selectedIdx = idx; repaintWithSelection(); renderList(); renderInspector(); };

      layerCtl.appendChild(up); layerCtl.appendChild(down);
      row.appendChild(swatch); row.appendChild(label); row.appendChild(layerCtl);
      list.appendChild(row);
    });
  };

  // ---- schema-driven inspector (with fallback) ----
  function renderInspectorFromSchema(container, object, commit) {
    container.innerHTML = "";
    if (!object) {
      const t = document.createElement("div");
      t.textContent = "Select an item to edit.";
      t.style.opacity = ".7";
      container.appendChild(t);
      return;
    }

    // schema or fallback
    let schema = SchemaRegistry.get(object.type);
    if (!schema) {
      schema = {
        fields: [
          // Position/Size
          { group: "Position", label: "X", type: "number", path: "data.x", showIf: o => o?.data?.x != null },
          { group: "Position", label: "Y", type: "number", path: "data.y", showIf: o => o?.data?.y != null },
          { group: "Size", label: "W", type: "number", path: "data.width", showIf: o => o?.data?.width != null },
          { group: "Size", label: "H", type: "number", path: "data.height", showIf: o => o?.data?.height != null },
          { group: "Size", label: "Radius", type: "number", path: "data.r", showIf: o => o?.data?.r != null },

          // Lines
          { group: "Position", label: "x1", type: "number", path: "data.x1", showIf: o => o?.data?.x1 != null },
          { group: "Position", label: "y1", type: "number", path: "data.y1", showIf: o => o?.data?.y1 != null },
          { group: "Position", label: "x2", type: "number", path: "data.x2", showIf: o => o?.data?.x2 != null },
          { group: "Position", label: "y2", type: "number", path: "data.y2", showIf: o => o?.data?.y2 != null },

          // Poly-like
          {
            group: "Points", label: "Points (JSON)", type: "textarea", path: "data.points",
            showIf: o => Array.isArray(o?.data?.points),
            parse: v => { try { return JSON.parse(v); } catch { return []; } },
            format: v => JSON.stringify(v ?? [], null, 0)
          },

          // Style
          { group: "Style", label: "Stroke", type: "color", path: "style.stroke", showIf: o => o?.style?.stroke != null },
          { group: "Style", label: "Fill", type: "color", path: "style.fill", showIf: o => o?.style?.fill != null },
          { group: "Style", label: "Width", type: "number", path: "style.lineWidth", min: 1, step: 1, showIf: o => o?.style?.lineWidth != null },
          { group: "FX", label: "Opacity", type: "range", path: "style.opacity", min: 0, max: 1, step: 0.05, showIf: o => o?.style?.opacity != null },

          // Arrow extras if present
          { group: "Options", label: "Head size", type: "number", path: "style.headSize", min: 2, step: 1, showIf: o => o?.style?.headSize != null },
          { group: "Options", label: "Head type", type: "select", path: "style.headType", options: ["triangle", "barb", "open"], showIf: o => o?.style?.headType != null },

          // Text-like
          { group: "Text", label: "Content", type: "textarea", path: "data.text", showIf: o => o?.data?.text != null },
          { group: "Text", label: "Font", type: "text", path: "style.font", showIf: o => o?.style?.font != null },
          { group: "Text", label: "Align", type: "select", path: "style.align", options: ["left", "center", "right"], showIf: o => o?.style?.align != null },
        ]
      };
    }

    // group fields
    const groups = new Map();
    for (const f of schema.fields) {
      if (f.showIf && !f.showIf(object)) continue;
      const g = f.group || "General";
      if (!groups.has(g)) groups.set(g, []);
      groups.get(g).push(f);
    }

    const makeRow = (label, input) => {
      const wrap = document.createElement("div");
      Object.assign(wrap.style, {
        display: "grid",
        gridTemplateColumns: "1fr 1fr",
        gap: "6px",
        alignItems: "center"
      });
      const l = document.createElement("label");
      l.textContent = label;
      wrap.appendChild(l);
      wrap.appendChild(input);
      return wrap;
    };

    for (const [groupName, fields] of groups.entries()) {
      const title = document.createElement("div");
      title.textContent = groupName;
      Object.assign(title.style, { marginTop: "6px", fontWeight: "700", opacity: ".85" });
      container.appendChild(title);

      for (const f of fields) {
        const current = f.format ? f.format(dget(object, f.path)) : dget(object, f.path, "");
        let input;

        switch (f.type) {
          case "number": {
            input = document.createElement("input");
            input.type = "number";
            if (f.min !== undefined) input.min = String(f.min);
            if (f.max !== undefined) input.max = String(f.max);
            if (f.step !== undefined) input.step = String(f.step);
            input.value = current === "" ? "" : String(current);
            input.oninput = () => {
              const raw = input.value;
              const val = f.parse ? f.parse(raw) : parseFloat(raw);
              dset(object, f.path, (Number.isFinite(val) ? val : 0));
              commit();
            };
            break;
          }
          case "range": {
            input = document.createElement("input");
            input.type = "range";
            input.min = String(f.min ?? 0);
            input.max = String(f.max ?? 1);
            input.step = String(f.step ?? 0.01);
            input.value = String(current ?? 0);
            input.oninput = () => {
              const val = parseFloat(input.value);
              dset(object, f.path, val);
              commit();
            };
            break;
          }
          case "color": {
            input = document.createElement("input");
            input.type = "color";
            input.value = current || "#000000";
            input.oninput = () => {
              dset(object, f.path, input.value);
              commit();
            };
            break;
          }
          case "select": {
            input = document.createElement("select");
            (f.options || []).forEach(opt => {
              const o = document.createElement("option");
              o.value = opt; o.textContent = opt;
              input.appendChild(o);
            });
            input.value = current || (f.options?.[0] ?? "");
            input.onchange = () => {
              dset(object, f.path, input.value);
              commit(); // refresh if showIf toggles
            };
            break;
          }
          case "checkbox": {
            input = document.createElement("input");
            input.type = "checkbox";
            input.checked = !!current;
            input.onchange = () => {
              dset(object, f.path, !!input.checked);
              commit();
            };
            break;
          }
          case "textarea": {
            input = document.createElement("textarea");
            Object.assign(input.style, { minHeight: "80px", resize: "vertical" });
            input.value = current || "";
            input.oninput = () => {
              dset(object, f.path, input.value);
              commit();
            };
            break;
          }
          default: { // "text"
            input = document.createElement("input");
            input.type = "text";
            input.value = current || "";
            input.oninput = () => {
              dset(object, f.path, input.value);
              commit();
            };
          }
        }

        container.appendChild(makeRow(f.label || f.path, input));
      }
    }

    // Delete button
    const del = document.createElement("button");
    del.textContent = "Delete this item";
    Object.assign(del.style, { marginTop: "6px", background: "#ef4444", color: "#fff", border: "0", borderRadius: "8px", padding: "6px 10px", cursor: "pointer" });
    del.onclick = () => {
      const arr = getObjects().slice();
      if (selectedIdx >= 0 && selectedIdx < arr.length) {
        arr.splice(selectedIdx, 1);
        setObjects(arr);
        selectedIdx = -1;
        engine.renderAllObjects();
        renderList(); renderInspector();
      }
    };
    container.appendChild(del);
  }

  const renderInspector = () => {
    const objs = getObjects();
    const obj = objs[selectedIdx];
    const commit = () => { setObjects(objs.slice()); repaintWithSelection(); renderInspector(); };
    renderInspectorFromSchema(insp, obj, commit);
  };

  // export JSON
  const downloadJSON = (obj, filename) => {
    const blob = new Blob([JSON.stringify(obj, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = filename;
    document.body.appendChild(a); a.click();
    setTimeout(() => { document.body.removeChild(a); URL.revokeObjectURL(url); }, 0);
  };
  header.querySelector("#expSel").onclick = () => {
    const arr = getObjects();
    if (selectedIdx < 0 || !arr[selectedIdx]) return;
    downloadJSON(arr[selectedIdx], "canvas-object.json");
  };
  header.querySelector("#expAll").onclick = () => {
    downloadJSON(getObjects(), "canvas-objects.json");
  };

  // initial render
  renderList();
  renderInspector();

  // keep dock synced with store
  let unsub = null;
  try {
    unsub = useCanvasStore.subscribe(() => {
      renderList();
      renderInspector();
      if (selectedIdx >= getObjects().length) selectedIdx = -1;
      repaintWithSelection();
    });
  } catch {}

  // ---- canvas drag-to-move for selected item (hand cursor) ----
  const canvas = engine.canvas || engine.ctx?.canvas;
  const moveToggle = header.querySelector("#moveToggle");
  let draggingObj = false;
  let dragStart = null;
  let objStart = null;

  const toCanvasPos = (e) => {
    const rect = canvas.getBoundingClientRect();
    const sx = canvas.width / rect.width;
    const sy = canvas.height / rect.height;
    return { x: (e.clientX - rect.left) * sx, y: (e.clientY - rect.top) * sy };
  };

  function updateHoverCursor(pos) {
    if (selectedIdx < 0) { canvas.style.cursor = "default"; return; }
    const obj = getObjects()[selectedIdx];
    if (!obj) { canvas.style.cursor = "default"; return; }
    canvas.style.cursor = isHit(obj, pos) ? "grab" : "default";
  }

  const onPointerDown = (e) => {
    if (!moveToggle.checked) return;
    if (selectedIdx < 0) return;
    if (e.button !== 0) return;

    const objs = getObjects();
    const obj = objs[selectedIdx];
    if (!obj) return;

    const pos = toCanvasPos(e);
    updateHoverCursor(pos);
    if (!isHit(obj, pos)) return;

    draggingObj = true;
    dragStart = pos;

    const d = obj.data || {};
    if (obj.type === "polyline" || obj.type === "highlighter") {
      objStart = (d.points || []).map(p => ({ x: p.x, y: p.y }));
    } else {
      objStart = { x: Number(d.x || 0), y: Number(d.y || 0) };
    }

    canvas.style.cursor = "grabbing";
    e.preventDefault(); e.stopPropagation(); canvas.setPointerCapture?.(e.pointerId);
  };

  const onPointerMove = (e) => {
    const pos = toCanvasPos(e);

    if (!draggingObj) {
      if (moveToggle.checked) updateHoverCursor(pos);
      return;
    }

    const objs = getObjects();
    const obj = objs[selectedIdx];
    if (!obj) return;

    const dx = pos.x - dragStart.x;
    const dy = pos.y - dragStart.y;

    const d = obj.data || {};
    if (obj.type === "polyline" || obj.type === "highlighter") {
      const pts = d.points || [];
      for (let i = 0; i < pts.length; i++) {
        pts[i].x = objStart[i].x + dx;
        pts[i].y = objStart[i].y + dy;
      }
    } else {
      d.x = objStart.x + dx;
      d.y = objStart.y + dy;
    }

    setObjects(objs.slice());
    repaintWithSelection();
    e.preventDefault(); e.stopPropagation();
  };

  const endObjDrag = (e) => {
    if (!draggingObj) return;
    draggingObj = false;
    dragStart = null;
    objStart = null;
    canvas.style.cursor = "grab";
    canvas.releasePointerCapture?.(e.pointerId);
    e.preventDefault(); e.stopPropagation();
  };

  canvas.addEventListener("pointerdown", onPointerDown, true);
  canvas.addEventListener("pointermove", onPointerMove, true);
  canvas.addEventListener("pointerup", endObjDrag, true);
  canvas.addEventListener("pointercancel", endObjDrag, true);
  canvas.addEventListener("lostpointercapture", endObjDrag, true);

  // teardown
  panel.destroy = function () {
    unsub && unsub();
    canvas.removeEventListener("pointerdown", onPointerDown, true);
    canvas.removeEventListener("pointermove", onPointerMove, true);
    canvas.removeEventListener("pointerup", endObjDrag, true);
    canvas.removeEventListener("pointercancel", endObjDrag, true);
    canvas.removeEventListener("lostpointercapture", endObjDrag, true);
    if (panel.parentElement) panel.parentElement.removeChild(panel);
  };

  return panel;
}
