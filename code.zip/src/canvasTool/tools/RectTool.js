import { BaseTool } from "./BaseTool";
import { CanvasObject } from "../models/CanvasObject";
import { useCanvasStore } from "../state/canvasStore";

export class RectTool extends BaseTool {
  static inspector = [
    { group: "Position", label: "X", type: "number", path: "data.x" },
    { group: "Position", label: "Y", type: "number", path: "data.y" },
    { group: "Size", label: "W", type: "number", path: "data.width", min: 1 },
    { group: "Size", label: "H", type: "number", path: "data.height", min: 1 },

    { group: "Style", label: "Stroke", type: "color", path: "style.stroke" },
    { group: "Style", label: "Fill", type: "color", path: "style.fill" },
    {
      group: "Style",
      label: "Width",
      type: "number",
      path: "style.lineWidth",
      min: 1,
      step: 1,
    },

    {
      group: "FX",
      label: "Opacity",
      type: "range",
      path: "style.opacity",
      min: 0,
      max: 1,
      step: 0.05,
    },
  ];

  constructor() {
    super();
    this.name = "rect";
    this.startPos = null;
    this.snapshot = null;
  }

  onMouseDown(event, pos, engine) {
    const { color, lineWidth } = this.getToolOptions(engine.store);

    this.startPos = pos;
    this.snapshot = engine.ctx.getImageData(0, 0, engine.width, engine.height);

    engine.ctx.strokeStyle = color;
    engine.ctx.lineWidth = lineWidth;
  }

  onMouseMove(event, pos, engine) {
    if (!this.snapshot || !this.startPos) return;

    engine.ctx.putImageData(this.snapshot, 0, 0);
    const width = pos.x - this.startPos.x;
    const height = pos.y - this.startPos.y;
    engine.ctx.strokeRect(this.startPos.x, this.startPos.y, width, height);
  }

  onMouseUp(event, pos, engine) {
    const width = pos.x - this.startPos.x;
    const height = pos.y - this.startPos.y;

    const store = useCanvasStore.getState();

    store.addObject(
      new CanvasObject({
        type: "rectangle",
        data: {
          x: this.startPos.x,
          y: this.startPos.y,
          width,
          height,
        },
        style: {
          stroke: store.color,
          fill: "none",
        },
        layer: 0,
      })
    );

    this.startPos = null;
    this.snapshot = null;
  }
}
