import { PencilTool } from "./PencilTool";
import { EraserTool } from "./EraserTool";
import { LineTool } from "./LineTool";
import { RectTool } from "./RectTool";
import { CircleTool } from "./CircleTool";
import { ArrowTool } from "./ArrowTool";
import { CalloutTool } from "./CalloutTool";
import { PolylineTool } from "./PolylineTool";
import { SnapshotTool } from "./SnapshotTool";
import { WatermarkTool } from "./WatermarkTool";
import { TextTool } from "./TextTool";
import { HighlighterTool } from "./HighlighterTool";
import { StickyNoteTool } from "./StickyNoteTool";
import { SchemaRegistry } from "../utils/schemaRegistry";

export const toolRegistry = {
  pencil: new PencilTool(),
  eraser: new EraserTool(),
  line: new LineTool(),
  rect: new RectTool(),
  circle: new CircleTool(),
  arrow: new ArrowTool(),
  callout: new CalloutTool(),
  polyline: new PolylineTool(),
  snapshot: new SnapshotTool(),
  watermark: new WatermarkTool(),
  text: new TextTool(),
  highlighter: new HighlighterTool(),
  stickynote: new StickyNoteTool(),
};

SchemaRegistry.registerFromTools(toolRegistry);

export const toolList = [
  { name: "pencil", icon: "✏️", label: "Pencil" },
  { name: "line", icon: "📏", label: "Line" },
  { name: "rect", icon: "⬜", label: "Rectangle" },
  { name: "circle", icon: "⭕", label: "Circle" },
  { name: "arrow", icon: "➡️", label: "Arrow" },
  { name: "callout", icon: "💬", label: "Callout" },
  { name: "eraser", icon: "🧽", label: "Eraser" },
  { name: "polyline", icon: "〰️", label: "Polyline" },
  { name: "snapshot", icon: "📸", label: "Snapshot" },
  { name: "watermark", icon: "🏷️", label: "Watermark" },
  { name: "text", icon: "🅣", label: "Text" },
  { name: "highlighter", icon: "🖍️", label: "Highlighter" },
  { name: "stickynote", icon: "🗒️", label: "Sticky" },
];
